@echo off
chcp 65001 > nul
echo ====================================================
echo   Сборка FpvDronePlugin для Minecraft 26.2 (Paper)
echo ====================================================
echo.

where mvn >nul 2>nul
if %errorlevel% neq 0 (
    echo [ОШИБКА] Утилита Maven не найдена в переменной PATH!
    echo Установите Maven (https://maven.apache.org/download.cgi)
    echo или используйте сборку через IntelliJ IDEA / Docker / GitHub Actions.
    echo.
    pause
    exit /b 1
)

where javac >nul 2>nul
if %errorlevel% neq 0 (
    echo [ПРЕДУПРЕЖДЕНИЕ] Компилятор javac не найден в PATH. Убедитесь, что установлен JDK 21+.
)

echo Запуск: mvn clean package...
echo.
call mvn clean package
if %errorlevel% neq 0 (
    echo.
    echo [ОШИБКА] Сборка завершилась с ошибкой. Проверьте вывод выше.
    pause
    exit /b %errorlevel%
)

echo.
echo ====================================================
echo [УСПЕХ] Сборка успешно завершена!
echo Готовый плагин: target\FpvDronePlugin-26.2.0.jar
echo Скопируйте его в папку plugins/ вашего сервера Paper 26.2!
echo ====================================================
echo.
pause
