# Инструкция по сборке FpvDronePlugin (Minecraft 26.2)

Готовый исходный проект плагина FPV-дрона с честной 6-DOF физикой, оператором Citizens2 и поддержкой 3D-моделей.

---

## Вариант 1. Сборка на компьютере в 1 клик (Windows / macOS / Linux)

### Требования
1. **JDK 21** (или новее) — скачать [Eclipse Temurin JDK 21](https://adoptium.net/temurin/releases/?version=21).
2. **Apache Maven** — скачать [Maven](https://maven.apache.org/download.cgi) (распаковать и добавить папку `bin` в системную переменную `PATH`).

### Сборка
- **Windows**: просто дважды кликните по файлу `build.bat`.
- **macOS / Linux**: откройте терминал в папке проекта и выполните:
  ```bash
  chmod +x build.sh
  ./build.sh
  ```
- **Или универсальная команда Maven**:
  ```bash
  mvn clean package
  ```

Готовый файл появится в:
`target/FpvDronePlugin-26.2.0.jar`

---

## Вариант 2. Сборка через IntelliJ IDEA (без ручной настройки Maven)

1. Откройте **IntelliJ IDEA** (Community или Ultimate).
2. Нажмите **Open** (или `File -> Open`) и выберите папку `FpvDronePlugin` (где лежит файл `pom.xml`).
3. IDEA автоматически распознает проект Maven и загрузит зависимости Paper и Citizens.
4. Справа откройте панель **Maven** -> раскройте `FpvDronePlugin` -> `Lifecycle`.
5. Дважды кликните по пункту **package**.
6. В папке `target` появится скомпилированный `.jar`!

---

## Вариант 3. Сборка в облаке через GitHub Actions (вообще без установки программ на ПК!)

Если у вас нет установленного JDK или Maven:
1. Создайте бесплатный репозиторий на [GitHub](https://github.com).
2. Загрузите файлы из этой папки (включая папку `.github/workflows/build.yml`).
3. Перейдите во вкладку **Actions** в репозитории — GitHub автоматически запустит сервер Ubuntu с JDK 21 и скомпилирует плагин.
4. По завершении скачайте готовый архив с `.jar` файлом из блока **Artifacts**.

---

## Вариант 4. Сборка через Docker

Если у вас установлен Docker:
```bash
docker run --rm -v "%cd%:/app" -w /app maven:3.9-eclipse-temurin-21 mvn clean package
```

---

## Установка на сервер Paper 26.2

1. Поместите скомпилированный `FpvDronePlugin-26.2.0.jar` в папку `plugins/` вашего сервера Paper 26.2.
2. Поместите плагин **Citizens2** (версия под 26.2) в папку `plugins/`.
3. Перезапустите сервер.
4. В игре введите `/fpv kit` для получения полного набора оператора!
