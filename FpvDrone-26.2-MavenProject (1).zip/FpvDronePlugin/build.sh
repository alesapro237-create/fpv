#!/usr/bin/env bash
set -e
echo "===================================================="
echo "  Сборка FpvDronePlugin для Minecraft 26.2 (Paper)"
echo "===================================================="
echo ""

if ! command -v mvn &> /dev/null; then
    echo "[ОШИБКА] Maven не установлен! Установите его через apt, brew или скачайте с maven.apache.org."
    exit 1
fi

echo "Запуск: mvn clean package..."
mvn clean package

echo ""
echo "===================================================="
echo "[УСПЕХ] Сборка завершена: target/FpvDronePlugin-26.2.0.jar"
echo "===================================================="
