package ru.fpvdrone;

import net.citizensnpcs.api.CitizensAPI;
import net.citizensnpcs.api.npc.NPC;
import net.citizensnpcs.api.trait.trait.Equipment;
import net.citizensnpcs.trait.SkinTrait;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.FluidCollisionMode;
import org.bukkit.GameMode;
import org.bukkit.Input;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.event.player.PlayerToggleFlightEvent;
import org.bukkit.event.player.PlayerToggleSneakEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * FPV Drone Plugin for Minecraft 26.2 (Paper API + Citizens2 API).
 *
 * Особенности реализации:
 * 1. Честная 6-DOF физика настоящего FPV-квадрокоптера:
 *    - Тяга винтов направлена вдоль локальной оси Y рамы дрона (вычисляется через кватернион Quaternionf).
 *    - Движение вперёд/назад и вбок происходит только за счёт наклона вектора тяги (Pitch / Roll), как у реального дрона.
 *    - Режимы полётного контроллера: ACRO (удержание угла без автовыравнивания, поддержка флипов/роллов 360°)
 *      и ANGLE (стабилизация горизонта с ограничением угла наклона).
 *    - Учёт массы рамы и боевой нагрузки, квадратичного сопротивления воздуха (Drag), гравитации,
 *      эффекта воздушной подушки у земли (Ground Effect) и просадки напряжения 6S LiPo батареи.
 * 2. Оператор — реальный игрок-NPC через Citizens2 (EntityType.PLAYER, НЕ ArmorStand):
 *    - На месте запуска остаётся уязвимый NPC со скином игрока, его бронёй, 3D FPV-очками на голове
 *      и 3D пультом радиоуправления в руках.
 *    - Если враг атакует или убивает NPC-оператора, урон мгновенно передаётся настоящему игроку,
 *      а при смерти оператора связь с дроном обрывается.
 * 3. Визуализация 3D-модели через ItemDisplay + Ресурспак (формат 88.0 для Minecraft 26.2):
 *    - Поддержка как нового компонента item_model (fpvdrone:fpv_drone / fpv_controller / fpv_goggles),
 *      так и CustomModelData (26201, 26202, 26203) на PHANTOM_MEMBRANE.
 */
public final class FpvDronePlugin extends JavaPlugin implements Listener, CommandExecutor, TabCompleter {

    // Ключи метаданных и моделей ресурспака
    private NamespacedKey itemTypeKey;
    private NamespacedKey droneModelKey;
    private NamespacedKey controllerModelKey;
    private NamespacedKey gogglesModelKey;

    public static final int CMD_DRONE = 26201;
    public static final int CMD_CONTROLLER = 26202;
    public static final int CMD_GOGGLES = 26203;

    // Активные полётные сессии: UUID игрока -> сессия дрона
    private final Map<UUID, DroneSession> sessionsByPlayer = new HashMap<>();
    // Обратный индекс: UUID сущности NPC Citizens2 -> UUID игрока-оператора
    private final Map<UUID, UUID> playerByNpcEntity = new HashMap<>();

    private BukkitTask physicsTask;

    // Конфигурируемые физические параметры
    private double frameMassKg;
    private double payloadMassKg;
    private double maxThrustNewtons;
    private double dragCoefficient;
    private double gravityAcc;
    private double maxAngleDeg;
    private double acroPitchRateDegPerSec;
    private double acroRollRateDegPerSec;
    private double yawRateDegPerSec;
    private double cameraUptiltDeg;
    private double maxSignalRangeMeters;
    private double batteryCapacitySeconds;
    private float payloadExplosionPower;
    private float kamikazeExplosionPower;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadPhysicsConfig();

        this.itemTypeKey = new NamespacedKey(this, "fpv_item_type");
        this.droneModelKey = new NamespacedKey("fpvdrone", "fpv_drone");
        this.controllerModelKey = new NamespacedKey("fpvdrone", "fpv_controller");
        this.gogglesModelKey = new NamespacedKey("fpvdrone", "fpv_goggles");

        if (Bukkit.getPluginManager().getPlugin("Citizens") == null) {
            getLogger().severe("Citizens2 не найден! Для создания оператора-игрока требуется плагин Citizens2.");
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }

        Bukkit.getPluginManager().registerEvents(this, this);

        if (getCommand("fpv") != null) {
            getCommand("fpv").setExecutor(this);
            getCommand("fpv").setTabCompleter(this);
        }

        // Главный цикл симуляции физики FPV (20 Гц, dt = 0.05 с)
        this.physicsTask = new BukkitRunnable() {
            @Override
            public void run() {
                tickAllDrones(0.05);
            }
        }.runTaskTimer(this, 1L, 1L);

        getLogger().info("FpvDronePlugin 26.2 успешно запущен (Citizens2 Player Operator + 6-DOF Physics).");
    }

    @Override
    public void onDisable() {
        if (this.physicsTask != null) {
            this.physicsTask.cancel();
        }
        // Безопасно возвращаем всех операторов в их тела при выключении/перезагрузке
        for (UUID playerId : new ArrayList<>(sessionsByPlayer.keySet())) {
            stopDroneSession(playerId, "Сервер перезагружается — возврат управления оператору.", false);
        }
    }

    private void loadPhysicsConfig() {
        reloadConfig();
        this.frameMassKg = getConfig().getDouble("physics.frame-mass-kg", 0.65);
        this.payloadMassKg = getConfig().getDouble("physics.payload-mass-kg", 0.75);
        this.maxThrustNewtons = getConfig().getDouble("physics.max-thrust-newtons", 34.0);
        this.dragCoefficient = getConfig().getDouble("physics.drag-coefficient", 0.24);
        this.gravityAcc = getConfig().getDouble("physics.gravity-m-s2", 9.81);
        this.maxAngleDeg = getConfig().getDouble("physics.max-angle-deg", 55.0);
        this.acroPitchRateDegPerSec = getConfig().getDouble("physics.acro-pitch-rate-deg-s", 160.0);
        this.acroRollRateDegPerSec = getConfig().getDouble("physics.acro-roll-rate-deg-s", 180.0);
        this.yawRateDegPerSec = getConfig().getDouble("physics.yaw-rate-deg-s", 140.0);
        this.cameraUptiltDeg = getConfig().getDouble("physics.camera-uptilt-deg", 22.5);
        this.maxSignalRangeMeters = getConfig().getDouble("drone.max-signal-range-meters", 220.0);
        this.batteryCapacitySeconds = getConfig().getDouble("drone.battery-flight-seconds", 180.0);
        this.payloadExplosionPower = (float) getConfig().getDouble("combat.payload-explosion-power", 3.2);
        this.kamikazeExplosionPower = (float) getConfig().getDouble("combat.kamikaze-explosion-power", 4.5);
    }

    // =========================================================================
    // СОЗДАНИЕ КАСТОМНЫХ ПРЕДМЕТОВ С 3D-МОДЕЛЯМИ ИЗ РЕСУРСПАКА
    // =========================================================================

    public ItemStack createDroneItem() {
        ItemStack item = new ItemStack(Material.PHANTOM_MEMBRANE, 1);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.displayName(Component.text("FPV Квадрокоптер «Шершень-26»", NamedTextColor.AQUA)
                    .decoration(TextDecoration.ITALIC, false)
                    .decoration(TextDecoration.BOLD, true));
            List<Component> lore = List.of(
                    Component.text("Карбоновая рама 5\" | 6S LiPo | Боевой подвес", NamedTextColor.GRAY)
                            .decoration(TextDecoration.ITALIC, false),
                    Component.empty(),
                    Component.text("▸ ПКМ с пультом или дроном — запуск FPV", NamedTextColor.YELLOW)
                            .decoration(TextDecoration.ITALIC, false),
                    Component.text("▸ Колёсико мыши / Space-Shift — Тяга (Throttle)", NamedTextColor.GREEN)
                            .decoration(TextDecoration.ITALIC, false),
                    Component.text("▸ W/S и мышь — Тангаж (Pitch) и Рыскание (Yaw)", NamedTextColor.GREEN)
                            .decoration(TextDecoration.ITALIC, false),
                    Component.text("▸ A/D — Крен (Roll) | F — Режим ACRO / ANGLE", NamedTextColor.GREEN)
                            .decoration(TextDecoration.ITALIC, false),
                    Component.text("▸ ЛКМ — Сброс боеприпаса / Взвод Камикадзе", NamedTextColor.RED)
                            .decoration(TextDecoration.ITALIC, false),
                    Component.text("▸ ПКМ в полёте — Зум + Тепловизор | Q — Выход", NamedTextColor.GOLD)
                            .decoration(TextDecoration.ITALIC, false)
            );
            meta.lore(lore);
            meta.setCustomModelData(CMD_DRONE);
            meta.setItemModel(droneModelKey);
            meta.getPersistentDataContainer().set(itemTypeKey, PersistentDataType.STRING, "DRONE");
            meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
            item.setItemMeta(meta);
        }
        return item;
    }

    public ItemStack createControllerItem() {
        ItemStack item = new ItemStack(Material.PHANTOM_MEMBRANE, 1);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.displayName(Component.text("Аппаратура управления FPV (ELRS 2.4GHz)", NamedTextColor.GOLD)
                    .decoration(TextDecoration.ITALIC, false)
                    .decoration(TextDecoration.BOLD, true));
            meta.lore(List.of(
                    Component.text("Двухосевые стики Hall Sensor + OLED телеметрия", NamedTextColor.GRAY)
                            .decoration(TextDecoration.ITALIC, false),
                    Component.text("Нажмите ПКМ, чтобы развернуть и запустить FPV-дрон", NamedTextColor.YELLOW)
                            .decoration(TextDecoration.ITALIC, false)
            ));
            meta.setCustomModelData(CMD_CONTROLLER);
            meta.setItemModel(controllerModelKey);
            meta.getPersistentDataContainer().set(itemTypeKey, PersistentDataType.STRING, "CONTROLLER");
            item.setItemMeta(meta);
        }
        return item;
    }

    public ItemStack createGogglesItem() {
        ItemStack item = new ItemStack(Material.PHANTOM_MEMBRANE, 1);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.displayName(Component.text("FPV Видеоочки оператора (5.8GHz Diversity)", NamedTextColor.AQUA)
                    .decoration(TextDecoration.ITALIC, false));
            meta.setCustomModelData(CMD_GOGGLES);
            meta.setItemModel(gogglesModelKey);
            meta.getPersistentDataContainer().set(itemTypeKey, PersistentDataType.STRING, "GOGGLES");
            item.setItemMeta(meta);
        }
        return item;
    }

    private boolean isCustomItem(ItemStack item, String expectedType) {
        if (item == null || item.getType() == Material.AIR || !item.hasItemMeta()) {
            return false;
        }
        String val = item.getItemMeta().getPersistentDataContainer().get(itemTypeKey, PersistentDataType.STRING);
        return expectedType.equals(val);
    }

    // =========================================================================
    // ЗАПУСК И ЗАВЕРШЕНИЕ СЕССИИ ПОЛЁТА (CITIZENS2 ОПЕРАТОР + ITEMDISPLAY ДРОН)
    // =========================================================================

    public void startDroneSession(Player player) {
        if (sessionsByPlayer.containsKey(player.getUniqueId())) {
            player.sendMessage(Component.text("Вы уже управляете FPV-дроном!", NamedTextColor.RED));
            return;
        }
        if (!player.isOnGround()) {
            player.sendMessage(Component.text("Для запуска FPV-дрона оператор должен стоять на земле!", NamedTextColor.RED));
            return;
        }

        Location operatorLoc = player.getLocation().clone();
        World world = operatorLoc.getWorld();
        if (world == null) return;

        // 1. Создаём живого NPC-оператора через Citizens2 (строго EntityType.PLAYER, никакого ArmorStand!)
        NPC operatorNpc = CitizensAPI.getNPCRegistry().createNPC(EntityType.PLAYER, player.getName());
        SkinTrait skinTrait = operatorNpc.getOrAddTrait(SkinTrait.class);
        skinTrait.setSkinName(player.getName(), true);

        operatorNpc.spawn(operatorLoc);
        operatorNpc.setProtected(false); // Оператор уязвим для врагов во время полёта!

        // Экипируем NPC бронёй игрока, надеваем на голову 3D FPV-очки и даём в руки 3D пульт
        Equipment equipTrait = operatorNpc.getOrAddTrait(Equipment.class);
        if (player.getInventory().getChestplate() != null) {
            equipTrait.set(Equipment.EquipmentSlot.CHESTPLATE, player.getInventory().getChestplate().clone());
        }
        if (player.getInventory().getLeggings() != null) {
            equipTrait.set(Equipment.EquipmentSlot.LEGGINGS, player.getInventory().getLeggings().clone());
        }
        if (player.getInventory().getBoots() != null) {
            equipTrait.set(Equipment.EquipmentSlot.BOOTS, player.getInventory().getBoots().clone());
        }
        equipTrait.set(Equipment.EquipmentSlot.HELMET, createGogglesItem());
        equipTrait.set(Equipment.EquipmentSlot.HAND, createControllerItem());

        if (operatorNpc.getEntity() instanceof LivingEntity livingNpc) {
            AttributeInstance maxHpAttr = player.getAttribute(Attribute.MAX_HEALTH);
            double maxHp = maxHpAttr != null ? maxHpAttr.getValue() : 20.0;
            AttributeInstance npcMaxHp = livingNpc.getAttribute(Attribute.MAX_HEALTH);
            if (npcMaxHp != null) {
                npcMaxHp.setBaseValue(maxHp);
            }
            livingNpc.setHealth(Math.min(maxHp, Math.max(1.0, player.getHealth())));
        }

        // 2. Создаём 3D-модель дрона в мире через ItemDisplay в 1.5 м перед оператором
        Vector forwardFlat = operatorLoc.getDirection().setY(0).normalize();
        Location droneStartLoc = operatorLoc.clone().add(forwardFlat.multiply(1.5)).add(0, 0.35, 0);
        droneStartLoc.setPitch(0f);

        ItemDisplay droneDisplay = (ItemDisplay) world.spawnEntity(droneStartLoc, EntityType.ITEM_DISPLAY);
        droneDisplay.setItemStack(createDroneItem());
        droneDisplay.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.HEAD);
        droneDisplay.setInterpolationDuration(1);
        droneDisplay.setTeleportDuration(1);
        droneDisplay.setViewRange(2.5f);
        droneDisplay.setShadowRadius(0.35f);
        droneDisplay.setShadowStrength(0.8f);

        // 3. Переводим реального игрока в режим невидимой FPV-камеры
        DroneSession session = new DroneSession(player, operatorNpc, droneDisplay, operatorLoc, droneStartLoc);
        sessionsByPlayer.put(player.getUniqueId(), session);
        if (operatorNpc.getEntity() != null) {
            playerByNpcEntity.put(operatorNpc.getEntity().getUniqueId(), player.getUniqueId());
        }

        // Скрываем физическое тело игрока-камеры от всех остальных игроков (на месте старта стоит его NPC!)
        for (Player online : Bukkit.getOnlinePlayers()) {
            if (!online.equals(player)) {
                online.hidePlayer(this, player);
            }
        }

        player.setGameMode(GameMode.SURVIVAL);
        player.setAllowFlight(true);
        player.setFlying(true);
        player.setCollidable(false);
        player.setInvisible(true);
        player.setSilent(true);
        player.getInventory().setHeldItemSlot(4); // Центральный слот для отслеживания прокрутки колёсика (Throttle)

        player.teleport(droneStartLoc);
        player.showBossBar(session.hudBossBar);

        world.playSound(droneStartLoc, Sound.BLOCK_BEACON_ACTIVATE, 0.8f, 1.8f);
        player.showTitle(Title.title(
                Component.text("FPV СИСТЕМА АКТИВНА", NamedTextColor.AQUA),
                Component.text("Колёсико/Space: Газ | WASD+Мышь: Крен/Тангаж | F: ACRO/ANGLE | Q: Выход", NamedTextColor.GRAY),
                Title.Times.times(Duration.ofMillis(200), Duration.ofMillis(1800), Duration.ofMillis(400))
        ));
    }

    public void stopDroneSession(UUID playerId, String reason, boolean operatorKilled) {
        DroneSession session = sessionsByPlayer.remove(playerId);
        if (session == null) return;

        if (session.operatorNpc != null) {
            if (session.operatorNpc.getEntity() != null) {
                playerByNpcEntity.remove(session.operatorNpc.getEntity().getUniqueId());
            }
            if (session.operatorNpc.isSpawned()) {
                session.operatorNpc.despawn();
            }
            CitizensAPI.getNPCRegistry().deregister(session.operatorNpc);
        }

        if (session.droneDisplay != null && session.droneDisplay.isValid()) {
            session.droneDisplay.remove();
        }

        Player player = Bukkit.getPlayer(playerId);
        if (player != null && player.isOnline()) {
            player.hideBossBar(session.hudBossBar);
            player.removePotionEffect(PotionEffectType.NIGHT_VISION);
            player.removePotionEffect(PotionEffectType.SLOWNESS);
            player.removePotionEffect(PotionEffectType.BLINDNESS);
            player.removePotionEffect(PotionEffectType.NAUSEA);

            player.setInvisible(false);
            player.setSilent(false);
            player.setCollidable(true);

            // Возвращаем видимость игрока всем на сервере
            for (Player online : Bukkit.getOnlinePlayers()) {
                if (!online.equals(player)) {
                    online.showPlayer(this, player);
                }
            }

            // Возвращаем игрока точно на позицию его тела-оператора
            player.teleport(session.operatorLocation);
            player.setGameMode(session.previousGameMode);
            player.setAllowFlight(session.previousAllowFlight);
            player.setFlying(false);
            player.setFallDistance(0f);

            if (operatorKilled) {
                player.sendMessage(Component.text("✖ Ваш оператор погиб! Связь с FPV-дроном потеряна.", NamedTextColor.RED));
                player.setHealth(0.0);
            } else if (reason != null && !reason.isEmpty()) {
                player.sendMessage(Component.text("▪ " + reason, NamedTextColor.YELLOW));
            }
        }
    }

    // =========================================================================
    // ЦИКЛ ФИЗИЧЕСКОЙ СИМУЛЯЦИИ 6-DOF (20 TPS)
    // =========================================================================

    private void tickAllDrones(double dt) {
        for (UUID playerId : new ArrayList<>(sessionsByPlayer.keySet())) {
            DroneSession session = sessionsByPlayer.get(playerId);
            if (session == null) continue;

            Player player = Bukkit.getPlayer(playerId);
            if (player == null || !player.isOnline()) {
                stopDroneSession(playerId, null, false);
                continue;
            }

            // Проверяем, жив ли NPC-оператор
            if (session.operatorNpc == null || !session.operatorNpc.isSpawned()) {
                stopDroneSession(playerId, "Оператор потерял сознание!", true);
                continue;
            }

            tickSingleDrone(player, session, dt);
        }
    }

    private void tickSingleDrone(Player player, DroneSession s, double dt) {
        World world = s.droneLocation.getWorld();
        if (world == null) return;

        // 1. Расход заряда 6S LiPo батареи (зависит от квадрата тяги)
        double currentDrawFactor = 0.35 + 1.45 * (s.throttle * s.throttle);
        s.batteryRemainingSec = Math.max(0.0, s.batteryRemainingSec - dt * currentDrawFactor);
        double batteryRatio = s.batteryRemainingSec / batteryCapacitySeconds;

        if (batteryRatio <= 0.0) {
            // Полный разряд аккумулятора — моторы отключаются, свободное падение
            s.throttle = 0.0;
            if (s.ticksExisted % 20 == 0) {
                player.sendMessage(Component.text("⚠ АККУМУЛЯТОР 0% (20.4V) — ОТКАЗ МОТОРОВ!", NamedTextColor.RED));
            }
        }

        // 2. Считывание ввода игрока (Paper 26.2 Input API + взгляд мыши)
        Input input = player.getCurrentInput();

        // Управление тягой (Throttle) через Space / Shift (дополнительно к колёсику мыши)
        if (batteryRatio > 0.0) {
            if (input.isJump()) {
                s.throttle = Math.min(1.0, s.throttle + 0.55 * dt);
            }
            if (input.isSneak()) {
                s.throttle = Math.max(0.0, s.throttle - 0.65 * dt);
            }
        }

        // Считываем отклонение взгляда мыши игрока для рыскания (Yaw) и точного тангажа (Pitch)
        Location pLoc = player.getLocation();
        float mouseYawDelta = wrapAngleDeg(pLoc.getYaw() - s.yawDeg);
        float mousePitchTarget = pLoc.getPitch();

        // Обновляем рыскание (Yaw) с плавным угловым откликом
        double yawStep = clamp(mouseYawDelta * 0.55, -yawRateDegPerSec * dt, yawRateDegPerSec * dt);
        s.yawDeg = wrapAngleDeg((float) (s.yawDeg + yawStep));

        // Ввод по крену (Roll: A / D) и тангажу (Pitch: W / S)
        double forwardIn = (input.isForward() ? 1.0 : 0.0) - (input.isBackward() ? 1.0 : 0.0);
        double rollIn = (input.isRight() ? 1.0 : 0.0) - (input.isLeft() ? 1.0 : 0.0);

        if (s.acroMode) {
            // РЕЖИМ ACRO (Betaflight Manual Rate Mode):
            // Рама НЕ выравнивается в горизонт сама! Отпустил клавишу — дрон держит текущий угол наклона.
            double targetPitchRate = forwardIn * acroPitchRateDegPerSec + clamp(mousePitchTarget * 0.35, -35.0, 35.0);
            double targetRollRate = rollIn * acroRollRateDegPerSec;

            // Инерция угловой скорости рамы (PID-демпфирование)
            s.pitchRateDegPerSec += (targetPitchRate - s.pitchRateDegPerSec) * Math.min(1.0, 12.0 * dt);
            s.rollRateDegPerSec += (targetRollRate - s.rollRateDegPerSec) * Math.min(1.0, 12.0 * dt);

            s.pitchDeg = wrapAngleDeg((float) (s.pitchDeg + s.pitchRateDegPerSec * dt));
            s.rollDeg = wrapAngleDeg((float) (s.rollDeg + s.rollRateDegPerSec * dt));
        } else {
            // РЕЖИМ ANGLE (Стабилизированный горизонт):
            // При отпускании клавиш рама плавно возвращается в 0°, углы ограничены ±maxAngleDeg.
            double desiredPitch = clamp(forwardIn * maxAngleDeg * 0.75 + mousePitchTarget * 0.35, -maxAngleDeg, maxAngleDeg);
            double desiredRoll = clamp(rollIn * maxAngleDeg * 0.85, -maxAngleDeg, maxAngleDeg);

            double pitchDiff = desiredPitch - s.pitchDeg;
            double rollDiff = desiredRoll - s.rollDeg;

            s.pitchRateDegPerSec = pitchDiff * 6.5;
            s.rollRateDegPerSec = rollDiff * 7.0;

            s.pitchDeg = (float) clamp(s.pitchDeg + s.pitchRateDegPerSec * dt, -maxAngleDeg, maxAngleDeg);
            s.rollDeg = (float) clamp(s.rollDeg + s.rollRateDegPerSec * dt, -maxAngleDeg, maxAngleDeg);
        }

        // 3. Вычисление 3D-ориентации рамы (Quaternionf) и вектора тяги винтов
        float yawRad = (float) Math.toRadians(-s.yawDeg);
        float pitchRad = (float) Math.toRadians(s.pitchDeg);
        float rollRad = (float) Math.toRadians(s.rollDeg);

        Quaternionf frameRot = new Quaternionf()
                .rotateY(yawRad)
                .rotateX(pitchRad)
                .rotateZ(rollRad);

        // Локальный вектор тяги винтов (0, 1, 0) поворачивается кватернионом рамы в мировые координаты
        Vector3f thrustDirJoml = frameRot.transform(new Vector3f(0f, 1f, 0f));
        Vector thrustDir = new Vector(thrustDirJoml.x, thrustDirJoml.y, thrustDirJoml.z);

        // Учёт просадки напряжения батареи (Voltage Sag) и воздушной подушки у земли (Ground Effect)
        double voltageSagFactor = 0.80 + 0.20 * batteryRatio;
        double groundEffectFactor = computeGroundEffect(s.droneLocation);
        double thrustMagnitude = s.throttle * maxThrustNewtons * voltageSagFactor * groundEffectFactor;

        Vector thrustForce = thrustDir.multiply(thrustMagnitude);

        // Квадратичное аэродинамическое сопротивление воздуха: F_drag = -0.5 * Cd * |v| * v
        double speed = s.velocity.length();
        Vector dragForce = s.velocity.clone().multiply(-0.5 * dragCoefficient * speed);

        // Полная масса дрона (уменьшается после сброса боеприпаса!)
        double totalMass = frameMassKg + (s.payloadAttached ? payloadMassKg : 0.0);

        // Ускорение: a = (F_thrust + F_drag) / m + g
        Vector acceleration = thrustForce.add(dragForce).multiply(1.0 / totalMass);
        acceleration.setY(acceleration.getY() - gravityAcc);

        // Интегрируем скорость
        s.velocity.add(acceleration.multiply(dt));

        // 4. Проверка столкновений (RayTrace по блокам и сущностям)
        Vector step = s.velocity.clone().multiply(dt);
        double stepLen = step.length();

        if (stepLen > 1e-4) {
            // Проверка попадания в живую цель при взведённом детонаторе Камикадзе
            if (s.kamikazeArmed) {
                RayTraceResult entityHit = world.rayTraceEntities(
                        s.droneLocation,
                        step.clone().normalize(),
                        Math.max(0.65, stepLen),
                        0.45,
                        ent -> ent != player
                                && ent != s.droneDisplay
                                && (s.operatorNpc.getEntity() == null || !ent.equals(s.operatorNpc.getEntity()))
                                && ent instanceof LivingEntity
                );
                if (entityHit != null && entityHit.getHitEntity() != null) {
                    triggerKamikazeDetonation(player, s, entityHit.getHitPosition().toLocation(world));
                    return;
                }
            }

            RayTraceResult blockHit = world.rayTraceBlocks(
                    s.droneLocation,
                    step.clone().normalize(),
                    stepLen + 0.25,
                    FluidCollisionMode.NEVER,
                    true
            );

            if (blockHit != null && blockHit.getHitBlock() != null && blockHit.getHitBlockFace() != null) {
                double impactSpeed = s.velocity.length();

                // Если взведён режим Камикадзе и удар достаточно сильный — детонация!
                if (s.kamikazeArmed && impactSpeed > 4.5) {
                    triggerKamikazeDetonation(player, s, blockHit.getHitPosition().toLocation(world));
                    return;
                }

                // Жёсткое столкновение (> 13 м/с) разрушает раму дрона
                if (impactSpeed > 13.5) {
                    world.spawnParticle(Particle.EXPLOSION, s.droneLocation, 4, 0.2, 0.2, 0.2, 0.02);
                    world.playSound(s.droneLocation, Sound.ENTITY_GENERIC_EXPLODE, 0.9f, 1.4f);
                    stopDroneSession(player.getUniqueId(), "Дрон разбился при столкновении на скорости "
                            + String.format(Locale.US, "%.1f м/с!", impactSpeed), false);
                    return;
                }

                // Упругое отражение с гашением скорости и трением о поверхность
                Vector normal = blockHit.getHitBlockFace().getDirection();
                double vn = s.velocity.dot(normal);
                if (vn < 0) {
                    s.velocity.subtract(normal.clone().multiply(1.35 * vn));
                    s.velocity.multiply(0.65); // Трение корпуса
                }
                if (impactSpeed > 3.5) {
                    world.playSound(s.droneLocation, Sound.BLOCK_ANVIL_LAND, 0.35f, 1.8f);
                    world.spawnParticle(Particle.CRIT, s.droneLocation, 6, 0.15, 0.15, 0.15, 0.1);
                }
            } else {
                s.droneLocation.add(step);
            }
        }

        // 5. Проверка радиуса радиосвязи и помех (Signal RSSI)
        double distanceToOperator = s.droneLocation.distance(s.operatorLocation);
        double signalRatio = clamp(1.0 - (distanceToOperator / maxSignalRangeMeters), 0.0, 1.0);

        if (distanceToOperator >= maxSignalRangeMeters) {
            world.playSound(s.droneLocation, Sound.BLOCK_BEACON_DEACTIVATE, 1.0f, 0.7f);
            stopDroneSession(player.getUniqueId(), "Потеря радиосвязи! Превышена максимальная дальность ("
                    + (int) maxSignalRangeMeters + " м).", false);
            return;
        } else if (signalRatio < 0.22) {
            // Видеопомехи в аналоговом/цифровом канале при слабом сигнале
            player.addPotionEffect(new PotionEffect(PotionEffectType.NAUSEA, 45, 0, false, false, false));
            if (s.ticksExisted % 15 == 0) {
                player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BIT, 0.5f, 0.5f);
            }
        }

        // 6. Обновление 3D-модели ItemDisplay и положения камеры игрока
        s.droneLocation.setYaw(s.yawDeg);
        // Камера FPV наклонена вверх относительно рамы на cameraUptiltDeg (22.5°)
        float fpvViewPitch = (float) clamp(s.pitchDeg - cameraUptiltDeg * 0.65, -89.0, 89.0);
        s.droneLocation.setPitch(fpvViewPitch);

        if (s.droneDisplay != null && s.droneDisplay.isValid()) {
            Location displayLoc = s.droneLocation.clone();
            displayLoc.setYaw(0f);
            displayLoc.setPitch(0f);
            s.droneDisplay.teleport(displayLoc);

            // Масштаб и вращение 3D-модели через JOML Quaternionf
            Transformation transform = new Transformation(
                    new Vector3f(0f, -0.15f, 0f),
                    frameRot,
                    new Vector3f(0.85f, 0.85f, 0.85f),
                    new Quaternionf()
            );
            s.droneDisplay.setInterpolationDelay(0);
            s.droneDisplay.setInterpolationDuration(1);
            s.droneDisplay.setTransformation(transform);
        }

        // Синхронизируем позицию игрока-камеры с дроном без сброса плавности мыши
        Location camLoc = s.droneLocation.clone().add(0, -1.45, 0);
        camLoc.setYaw(pLoc.getYaw());
        camLoc.setPitch(pLoc.getPitch());
        player.teleport(camLoc);

        // 7. Звук бесколлекторных моторов (частота тона зависит от оборотов Throttle) и вихревые частицы
        if (s.throttle > 0.02 && batteryRatio > 0.0) {
            float motorPitch = (float) (0.65 + 1.35 * s.throttle);
            float motorVol = (float) (0.18 + 0.45 * s.throttle);
            if (s.ticksExisted % 2 == 0) {
                world.playSound(s.droneLocation, Sound.BLOCK_BEEHIVE_WORK, motorVol, motorPitch);
            }
            world.spawnParticle(Particle.CLOUD, s.droneLocation.clone().add(0, -0.1, 0),
                    1, 0.18, 0.04, 0.18, 0.01);
        }

        // Подсветка целей в тепловизионном режиме
        if (s.thermalZoomActive && s.ticksExisted % 10 == 0) {
            for (Entity nearby : world.getNearbyEntities(s.droneLocation, 45.0, 45.0, 45.0)) {
                if (nearby instanceof LivingEntity living && nearby != player) {
                    living.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 18, 0, false, false, false));
                }
            }
        }

        // 8. Обновление OSD-телеметрии (ActionBar + BossBar)
        updateTelemetryHud(player, s, speed, distanceToOperator, batteryRatio, signalRatio);
        s.ticksExisted++;
    }

    private double computeGroundEffect(Location loc) {
        World w = loc.getWorld();
        if (w == null) return 1.0;
        RayTraceResult ground = w.rayTraceBlocks(loc, new Vector(0, -1, 0), 1.0, FluidCollisionMode.ALWAYS, true);
        if (ground != null && ground.getHitPosition() != null) {
            double h = Math.max(0.05, loc.getY() - ground.getHitPosition().getY());
            if (h < 0.85) {
                return 1.0 + 0.18 * (1.0 - h / 0.85);
            }
        }
        return 1.0;
    }

    private void updateTelemetryHud(Player player, DroneSession s, double speedMs, double distM,
                                    double batteryRatio, double signalRatio) {
        int throttlePct = (int) Math.round(s.throttle * 100.0);
        double speedKmh = speedMs * 3.6;
        double voltage6S = 20.4 + 4.8 * batteryRatio; // 6S LiPo: 25.2V (100%) .. 20.4V (0%)
        int rssiDbm = (int) Math.round(-45.0 - (1.0 - signalRatio) * 65.0);

        String modeLabel = s.acroMode ? "§d§lACRO" : "§a§lANGLE";
        String payloadLabel;
        if (s.kamikazeArmed) {
            payloadLabel = "§4§l[КАМИКАДЗЕ ВЗВЕДЁН]";
        } else if (s.payloadAttached) {
            payloadLabel = "§e[ВОГ/ТНТ ГОТОВ]";
        } else {
            payloadLabel = "§7[ПУСТО]";
        }

        String osdLine = String.format(Locale.US,
                "%s §8| §fTHR: §b%3d%% §8| §fSPD: §a%.1f км/ч §8| §fPITCH/ROLL: §7%+d°/%+d° §8| §fBAT: §6%.1fV §8| §fRSSI: §b%ddBm §8| %s",
                modeLabel, throttlePct, speedKmh, (int) s.pitchDeg, (int) s.rollDeg, voltage6S, rssiDbm, payloadLabel);

        player.sendActionBar(Component.text(osdLine));

        // BossBar показывает заряд аккумулятора, высоту и дистанцию до оператора
        BossBar.Color barColor = batteryRatio > 0.45 ? BossBar.Color.GREEN
                : (batteryRatio > 0.20 ? BossBar.Color.YELLOW : BossBar.Color.RED);
        s.hudBossBar.color(barColor);
        s.hudBossBar.progress((float) clamp(batteryRatio, 0.0, 1.0));
        s.hudBossBar.name(Component.text(String.format(Locale.US,
                "FPV ТЕЛЕМЕТРИЯ  •  Дальность: %.0f / %.0f м  •  Высота Y: %.1f  •  Заряд 6S: %d%% %s",
                distM, maxSignalRangeMeters, s.droneLocation.getY(), (int) (batteryRatio * 100),
                s.thermalZoomActive ? " • [ТЕПЛОВИЗОР ВКЛ]" : ""), NamedTextColor.WHITE));
    }

    // =========================================================================
    // БОЕВЫЕ ФУНКЦИИ: СБРОС БОЕПРИПАСА, КАМИКАДЗЕ, ТЕПЛОВИЗОР/ЗУМ
    // =========================================================================

    private void handleLeftClickAction(Player player, DroneSession s) {
        World world = s.droneLocation.getWorld();
        if (world == null) return;

        // Если игрок зажал Shift + ЛКМ — взводим/снимаем ударный детонатор Камикадзе
        if (player.getCurrentInput().isSneak() || !s.payloadAttached) {
            if (!s.kamikazeArmed) {
                s.kamikazeArmed = true;
                world.playSound(s.droneLocation, Sound.BLOCK_NOTE_BLOCK_PLING, 1.0f, 2.0f);
                player.sendMessage(Component.text("⚠ Ударный детонатор КАМИКАДЗЕ взведён! Повторный ЛКМ+Shift — мгновенный подрыв.", NamedTextColor.RED));
            } else {
                triggerKamikazeDetonation(player, s, s.droneLocation);
            }
            return;
        }

        // Обычный ЛКМ при наличии подвеса — сброс осколочно-фугасного боеприпаса с сохранением инерции дрона
        s.payloadAttached = false;
        TNTPrimed munition = (TNTPrimed) world.spawnEntity(
                s.droneLocation.clone().add(0, -0.35, 0), EntityType.TNT);
        munition.setFuseTicks(45); // 2.25 секунды до подрыва
        munition.setYield(payloadExplosionPower);
        munition.setSource(player);
        munition.setVelocity(s.velocity.clone().multiply(0.85).add(new Vector(0, -0.15, 0)));

        // Отдача вверх при сбросе груза
        s.velocity.add(new Vector(0, 1.2, 0));
        world.playSound(s.droneLocation, Sound.ENTITY_IRON_GOLEM_ATTACK, 1.0f, 1.5f);
        player.sendMessage(Component.text("▼ Боеприпас сброшен! Масса дрона снижена на "
                + payloadMassKg + " кг — манёвренность увеличена.", NamedTextColor.GREEN));
    }

    private void triggerKamikazeDetonation(Player player, DroneSession s, Location impactLoc) {
        World world = impactLoc.getWorld();
        UUID playerId = player.getUniqueId();
        float yield = s.payloadAttached ? kamikazeExplosionPower : (kamikazeExplosionPower * 0.65f);

        stopDroneSession(playerId, "💥 FPV-дрон сдетонировал в цели!", false);

        if (world != null) {
            world.spawnParticle(Particle.EXPLOSION_EMITTER, impactLoc, 2, 0.1, 0.1, 0.1, 0.0);
            world.createExplosion(impactLoc, yield, false, true, player);
        }
    }

    private void toggleThermalZoom(Player player, DroneSession s) {
        s.thermalZoomActive = !s.thermalZoomActive;
        if (s.thermalZoomActive) {
            player.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, Integer.MAX_VALUE, 0, false, false, false));
            player.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, Integer.MAX_VALUE, 3, false, false, false));
            player.playSound(player.getLocation(), Sound.ITEM_SPYGLASS_USE, 0.9f, 1.3f);
        } else {
            player.removePotionEffect(PotionEffectType.NIGHT_VISION);
            player.removePotionEffect(PotionEffectType.SLOWNESS);
            player.playSound(player.getLocation(), Sound.ITEM_SPYGLASS_STOP_USING, 0.9f, 1.1f);
        }
    }

    // =========================================================================
    // ОБРАБОТЧИКИ СОБЫТИЙ (ВВОД ПИЛОТА И УЯЗВИМОСТЬ NPC-ОПЕРАТОРА)
    // =========================================================================

    @EventHandler(priority = EventPriority.HIGH)
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        DroneSession session = sessionsByPlayer.get(player.getUniqueId());

        if (session != null) {
            event.setCancelled(true);
            Action act = event.getAction();
            if (act == Action.LEFT_CLICK_AIR || act == Action.LEFT_CLICK_BLOCK) {
                handleLeftClickAction(player, session);
            } else if (act == Action.RIGHT_CLICK_AIR || act == Action.RIGHT_CLICK_BLOCK) {
                toggleThermalZoom(player, session);
            }
            return;
        }

        // Запуск дрона при клике ПКМ с пультом или дроном в руке
        if (event.getHand() != EquipmentSlot.HAND) return;
        Action action = event.getAction();
        if (action == Action.RIGHT_CLICK_AIR || action == Action.RIGHT_CLICK_BLOCK) {
            ItemStack item = event.getItem();
            if (isCustomItem(item, "DRONE") || isCustomItem(item, "CONTROLLER")) {
                event.setCancelled(true);
                startDroneSession(player);
            }
        }
    }

    @EventHandler
    public void onHotbarScrollThrottle(PlayerItemHeldEvent event) {
        Player player = event.getPlayer();
        DroneSession session = sessionsByPlayer.get(player.getUniqueId());
        if (session == null) return;

        int prev = event.getPreviousSlot();
        int next = event.getNewSlot();
        int diff = next - prev;
        if (diff > 4) diff -= 9;
        if (diff < -4) diff += 9;

        // Прокрутка вверх увеличивает тягу (Throttle), вниз — уменьшает с шагом 6%
        session.throttle = clamp(session.throttle - diff * 0.06, 0.0, 1.0);
        event.setCancelled(true);
        player.getInventory().setHeldItemSlot(4);
    }

    @EventHandler
    public void onSwapHandFlightMode(PlayerSwapHandItemsEvent event) {
        Player player = event.getPlayer();
        DroneSession session = sessionsByPlayer.get(player.getUniqueId());
        if (session == null) return;

        event.setCancelled(true);
        session.acroMode = !session.acroMode;
        session.pitchRateDegPerSec = 0.0;
        session.rollRateDegPerSec = 0.0;
        player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_CHIME, 0.8f, session.acroMode ? 1.6f : 1.1f);
        player.sendMessage(Component.text("▸ Режим полётного контроллера переключён на: "
                + (session.acroMode ? "ACRO (Ручное удержание углов / Фристайл)" : "ANGLE (Автогоризонт)"),
                session.acroMode ? NamedTextColor.LIGHT_PURPLE : NamedTextColor.GREEN));
    }

    @EventHandler
    public void onDropKeyExitDrone(PlayerDropItemEvent event) {
        Player player = event.getPlayer();
        if (sessionsByPlayer.containsKey(player.getUniqueId())) {
            event.setCancelled(true);
            stopDroneSession(player.getUniqueId(), "Управление FPV-дроном завершено оператором.", false);
        }
    }

    @EventHandler
    public void onOperatorNpcDamage(EntityDamageEvent event) {
        Entity victim = event.getEntity();

        // 1. Запрещаем прямой урон невидимому игроку-камере (урон должен идти только через его тело-NPC!)
        if (victim instanceof Player p && sessionsByPlayer.containsKey(p.getUniqueId())) {
            event.setCancelled(true);
            return;
        }

        // 2. Если атакован NPC-оператор Citizens2 — передаём урон реальному игроку!
        UUID operatorPlayerId = playerByNpcEntity.get(victim.getUniqueId());
        if (operatorPlayerId == null) return;

        Player realOperator = Bukkit.getPlayer(operatorPlayerId);
        if (realOperator == null || !realOperator.isOnline()) return;

        double finalDmg = event.getFinalDamage();
        if (victim instanceof LivingEntity npcLiving && (npcLiving.getHealth() - finalDmg <= 0.0)) {
            event.setCancelled(true);
            stopDroneSession(operatorPlayerId, null, true);
        } else {
            double newHp = Math.max(0.5, realOperator.getHealth() - finalDmg);
            realOperator.setHealth(newHp);
            realOperator.playSound(realOperator.getLocation(), Sound.ENTITY_PLAYER_HURT, 1.0f, 1.0f);
            realOperator.sendMessage(Component.text("⚠ ВНИМАНИЕ: Ваше тело оператора атаковано! Здоровье: "
                    + String.format(Locale.US, "%.1f ❤", newHp / 2.0), NamedTextColor.RED));
        }
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (event.getWhoClicked() instanceof Player p && sessionsByPlayer.containsKey(p.getUniqueId())) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onToggleFlight(PlayerToggleFlightEvent event) {
        if (sessionsByPlayer.containsKey(event.getPlayer().getUniqueId())) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        stopDroneSession(event.getPlayer().getUniqueId(), null, false);
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        stopDroneSession(event.getEntity().getUniqueId(), null, false);
    }

    // =========================================================================
    // КОМАНДЫ (/fpv kit | launch | stop | reload)
    // =========================================================================

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Команда доступна только игрокам.");
            return true;
        }

        if (args.length == 0 || args[0].equalsIgnoreCase("kit") || args[0].equalsIgnoreCase("give")) {
            player.getInventory().addItem(createDroneItem(), createControllerItem(), createGogglesItem());
            player.sendMessage(Component.text("✔ Выдан комплект оператора FPV (Дрон «Шершень-26», Пульт ELRS и Видеоочки)!", NamedTextColor.GREEN));
            return true;
        }

        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "launch", "start" -> startDroneSession(player);
            case "stop", "exit" -> {
                if (sessionsByPlayer.containsKey(player.getUniqueId())) {
                    stopDroneSession(player.getUniqueId(), "Полёт завершён по команде.", false);
                } else {
                    player.sendMessage(Component.text("Вы сейчас не находитесь в режиме полёта.", NamedTextColor.RED));
                }
            }
            case "reload" -> {
                if (!player.hasPermission("fpvdrone.admin")) {
                    player.sendMessage(Component.text("Недостаточно прав!", NamedTextColor.RED));
                    return true;
                }
                loadPhysicsConfig();
                player.sendMessage(Component.text("✔ Конфигурация физики FPV-дрона перезагружена.", NamedTextColor.GREEN));
            }
            default -> player.sendMessage(Component.text("Использование: /fpv [kit | launch | stop | reload]", NamedTextColor.YELLOW));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return List.of("kit", "launch", "stop", "reload");
        }
        return Collections.emptyList();
    }

    // =========================================================================
    // ВСПОМОГАТЕЛЬНЫЕ СТРУКТУРЫ И МАТЕМАТИКА
    // =========================================================================

    private static double clamp(double val, double min, double max) {
        return Math.max(min, Math.min(max, val));
    }

    private static float wrapAngleDeg(float angle) {
        angle %= 360.0f;
        if (angle >= 180.0f) angle -= 360.0f;
        if (angle < -180.0f) angle += 360.0f;
        return angle;
    }

    private final class DroneSession {
        final UUID playerUuid;
        final NPC operatorNpc;
        final ItemDisplay droneDisplay;
        final Location operatorLocation;
        final Location droneLocation;
        final GameMode previousGameMode;
        final boolean previousAllowFlight;
        final BossBar hudBossBar;

        // 6-DOF Физическое состояние дрона
        final Vector velocity = new Vector(0, 0, 0);
        double throttle = 0.0;
        float yawDeg;
        float pitchDeg = 0.0f;
        float rollDeg = 0.0f;
        double pitchRateDegPerSec = 0.0;
        double rollRateDegPerSec = 0.0;

        // Режимы и бортовые системы
        boolean acroMode = true; // По умолчанию честный режим ACRO как у реального FPV
        boolean payloadAttached = true;
        boolean kamikazeArmed = false;
        boolean thermalZoomActive = false;
        double batteryRemainingSec;
        long ticksExisted = 0;

        DroneSession(Player player, NPC operatorNpc, ItemDisplay droneDisplay,
                     Location operatorLocation, Location droneStartLoc) {
            this.playerUuid = player.getUniqueId();
            this.operatorNpc = operatorNpc;
            this.droneDisplay = droneDisplay;
            this.operatorLocation = operatorLocation.clone();
            this.droneLocation = droneStartLoc.clone();
            this.yawDeg = operatorLocation.getYaw();
            this.previousGameMode = player.getGameMode();
            this.previousAllowFlight = player.getAllowFlight();
            this.batteryRemainingSec = batteryCapacitySeconds;
            this.hudBossBar = BossBar.bossBar(
                    Component.text("FPV ТЕЛЕМЕТРИЯ", NamedTextColor.AQUA),
                    1.0f,
                    BossBar.Color.GREEN,
                    BossBar.Overlay.NOTCHED_10
            );
        }
    }
}
